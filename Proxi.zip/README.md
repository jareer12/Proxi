# Proxi

A Node.js app that automaticaly finds and checks proxies for you and shows them on a dashboard.

![Image](./preview.jpg)

## Install & Setup

```shell
## Download
git clone https://github.com/jareer12/Proxi.git
cd Proxi
## Modules
npm install
## Create File
touch ./Data/working.txt
```
